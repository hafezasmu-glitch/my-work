/* ============ CONTENT DATA ============ */

const MENU_ITEMS = [
  { name: "Espresso", cat: "coffee", price: 180, desc: "Double shot, walnut crema", img: "https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?w=500&q=80" },
  { name: "Cappuccino", cat: "coffee", price: 220, desc: "Steamed milk, cocoa dust", img: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=500&q=80" },
  { name: "Latte", cat: "coffee", price: 240, desc: "Silky milk, latte art", img: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=500&q=80" },
  { name: "Americano", cat: "coffee", price: 190, desc: "Long black, slow sipped", img: "https://images.unsplash.com/photo-1521302080334-4bebac2763a6?w=500&q=80" },
  { name: "Mocha", cat: "coffee", price: 260, desc: "Dark chocolate, espresso", img: "https://images.unsplash.com/photo-1578314675249-a6910f80cc4e?w=500&q=80" },
  { name: "Cold Coffee", cat: "coffee", price: 250, desc: "Iced, whipped, unhurried", img: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=500&q=80" },
  { name: "Masala Tea", cat: "tea", price: 120, desc: "Spiced, hand-brewed", img: "https://images.unsplash.com/photo-1597318181409-cf64d0b5d8ee?w=500&q=80" },
  { name: "Fresh Juice", cat: "tea", price: 160, desc: "Seasonal fruit, no ice cream", img: "https://images.unsplash.com/photo-1613478223719-2ab802602423?w=500&q=80" },
  { name: "Club Sandwich", cat: "food", price: 320, desc: "Triple stack, house fries", img: "https://images.unsplash.com/photo-1553909489-cd47e0ef937f?w=500&q=80" },
  { name: "Chocolate Cake", cat: "food", price: 280, desc: "Dark, dense, unapologetic", img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&q=80" },
  { name: "Cheesecake", cat: "food", price: 300, desc: "Baked, berry compote", img: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=500&q=80" },
  { name: "Croissant", cat: "food", price: 150, desc: "Butter-laminated, warm", img: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500&q=80" }
];

const BOOKS = [
  { title: "The Sealed Nectar", author: "Safi-ur-Rahman", cat: "Islamic", color: "#3B2418" },
  { title: "Stories of the Prophets", author: "Ibn Kathir", cat: "Islamic", color: "#4A2E1C" },
  { title: "The Alchemist", author: "Paulo Coelho", cat: "Novels", color: "#8B5A2B" },
  { title: "Norwegian Wood", author: "Haruki Murakami", cat: "Novels", color: "#2B4A5A" },
  { title: "Sapiens", author: "Yuval Noah Harari", cat: "History", color: "#C9A227" },
  { title: "A Brief History of Time", author: "Stephen Hawking", cat: "Academic", color: "#1A2E4A" },
  { title: "Clean Code", author: "Robert C. Martin", cat: "Programming", color: "#2E2E2E" },
  { title: "Eloquent JavaScript", author: "Marijn Haverbeke", cat: "Programming", color: "#B08D57" },
  { title: "Zero to One", author: "Peter Thiel", cat: "Business", color: "#5A3A1A" },
  { title: "The Lean Startup", author: "Eric Ries", cat: "Business", color: "#8B6F47" },
  { title: "Atomic Habits", author: "James Clear", cat: "Self Development", color: "#C9A227" },
  { title: "Deep Work", author: "Cal Newport", cat: "Self Development", color: "#3B3B3B" },
  { title: "Sapiens Junior", author: "Yuval N. Harari", cat: "Children", color: "#A65A2E" },
  { title: "Guns, Germs, and Steel", author: "Jared Diamond", cat: "History", color: "#4A3B2A" },
  { title: "The Design of Everyday Things", author: "Don Norman", cat: "Academic", color: "#6B4A2E" },
  { title: "Charlotte's Web", author: "E.B. White", cat: "Children", color: "#7A9E6B" }
];

const GALLERY = [
  { img: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=700&q=80", tag: "Interior", tall: true },
  { img: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=700&q=80", tag: "Coffee" },
  { img: "https://images.unsplash.com/photo-1481833761820-0509d3217039?w=700&q=80", tag: "Books" },
  { img: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?w=700&q=80", tag: "Customer moment", tall: true },
  { img: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=700&q=80", tag: "Coffee" },
  { img: "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=700&q=80", tag: "Interior" },
  { img: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=700&q=80", tag: "Books", tall: true },
  { img: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=700&q=80", tag: "Coffee" }
];

const EVENTS = [
  { day: "03", mon: "AUG", title: "Sunday Reading Circle", time: "5:00 PM", desc: "Bring a book, borrow a chair — silent reading, shared coffee." },
  { day: "10", mon: "AUG", title: "Coffee Tasting: Ethiopia", time: "6:30 PM", desc: "A guided cupping through three single-origin roasts." },
  { day: "17", mon: "AUG", title: "Author Meetup", time: "7:00 PM", desc: "An evening with a local novelist, Q&A and signing." },
  { day: "24", mon: "AUG", title: "Community Book Swap", time: "4:00 PM", desc: "Trade a paperback, leave with a new favourite." }
];

const TESTIMONIALS = [
  { name: "Rafiul Islam", role: "Regular, since 2019", quote: "The only place in Sylhet where I can lose two hours and not notice.", stars: 5 },
  { name: "Nadia Chowdhury", role: "Book club host", quote: "Their reading floor is quieter than my own living room.", stars: 5 },
  { name: "Tanvir Ahmed", role: "Coffee enthusiast", quote: "Best cappuccino in the city, and the shelf keeps surprising me.", stars: 5 },
  { name: "Farzana Begum", role: "Weekend visitor", quote: "I came for coffee, left with three books. Every single time.", stars: 4 }
];

const BLOG = [
  { title: "How We Choose What Goes on the Shelf", cat: "Books", time: "6 min read", img: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=600&q=80" },
  { title: "The Case for a Slower Cup", cat: "Coffee", time: "4 min read", img: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=600&q=80" },
  { title: "Notes From Our First Reading Circle", cat: "Community", time: "5 min read", img: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=600&q=80" }
];

const BESTSELLERS = ["Atomic Habits", "The Alchemist", "Sapiens", "Clean Code", "Deep Work", "The Sealed Nectar"];
