/* ============================================================
   WASEM COFFEE & BOOK SHOP — App logic
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- LOADER ---------- */
  const loader = document.getElementById('loader');
  const loaderBar = document.querySelector('.loader-bar-fill');
  requestAnimationFrame(() => loaderBar.style.width = '100%');
  window.addEventListener('load', () => {
    setTimeout(() => { loader.classList.add('hide'); playHeroReveal(); }, 1400);
  });
  // fallback in case load event already fired
  setTimeout(() => { if(!loader.classList.contains('hide')){ loader.classList.add('hide'); playHeroReveal(); } }, 3200);

  /* ---------- CUSTOM CURSOR ---------- */
  const dot = document.querySelector('.cursor-dot');
  const ring = document.querySelector('.cursor-ring');
  let mx=0,my=0, rx=0, ry=0;
  window.addEventListener('mousemove', e => { mx=e.clientX; my=e.clientY; dot.style.left=mx+'px'; dot.style.top=my+'px'; });
  (function loopCursor(){ rx += (mx-rx)*.18; ry += (my-ry)*.18; ring.style.left=rx+'px'; ring.style.top=ry+'px'; requestAnimationFrame(loopCursor); })();
  document.querySelectorAll('a,button,.tilt,.book-item,.menu-card').forEach(el=>{
    el.addEventListener('mouseenter', ()=>ring.classList.add('hovered'));
    el.addEventListener('mouseleave', ()=>ring.classList.remove('hovered'));
  });

  /* ---------- NAVBAR ---------- */
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 40);
    document.getElementById('backToTop').classList.toggle('show', window.scrollY > 700);
  });
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  hamburger.addEventListener('click', () => { hamburger.classList.toggle('open'); navLinks.classList.toggle('open'); });
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { hamburger.classList.remove('open'); navLinks.classList.remove('open'); }));
  document.getElementById('backToTop').addEventListener('click', () => window.scrollTo({top:0, behavior:'smooth'}));

  /* ---------- THEME TOGGLE ---------- */
  const themeToggle = document.getElementById('themeToggle');
  const savedTheme = localStorage.getItem('wasem-theme');
  if(savedTheme) document.body.setAttribute('data-theme', savedTheme);
  themeToggle.addEventListener('click', () => {
    const next = document.body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.body.setAttribute('data-theme', next);
    try{ localStorage.setItem('wasem-theme', next); }catch(e){}
  });

  /* ---------- STEAM PARTICLES ---------- */
  const steamField = document.getElementById('steamField');
  for(let i=0;i<14;i++){
    const p = document.createElement('div');
    p.className='puff';
    p.style.left = (10+Math.random()*80)+'%';
    p.style.height = (30+Math.random()*50)+'px';
    p.style.animationDuration = (6+Math.random()*6)+'s';
    p.style.animationDelay = (Math.random()*8)+'s';
    steamField.appendChild(p);
  }

  /* ---------- SCROLL REVEAL ---------- */
  const revealEls = document.querySelectorAll('.reveal-up, .reveal-line');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(en => { if(en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); } });
  }, { threshold: 0.15 });
  revealEls.forEach(el => io.observe(el));

  function playHeroReveal(){
    document.querySelectorAll('.hero .reveal-line, .hero .reveal-up').forEach((el,i)=>{
      setTimeout(()=>el.classList.add('in'), 120*i);
    });
  }

  /* ---------- COUNTER ANIMATION ---------- */
  const counters = document.querySelectorAll('.stat-num');
  const counterIO = new IntersectionObserver((entries)=>{
    entries.forEach(en=>{
      if(en.isIntersecting){
        animateCount(en.target);
        counterIO.unobserve(en.target);
      }
    });
  },{threshold:.4});
  counters.forEach(c=>counterIO.observe(c));
  function animateCount(el){
    const target = parseInt(el.dataset.count,10);
    const dur = 1800; const start = performance.now();
    function tick(now){
      const p = Math.min((now-start)/dur,1);
      const eased = 1 - Math.pow(1-p,3);
      el.textContent = Math.floor(eased*target).toLocaleString();
      if(p<1) requestAnimationFrame(tick);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }

  /* ================= RENDER: MENU ================= */
  const menuGrid = document.getElementById('menuGrid');
  function renderMenu(filter='all'){
    menuGrid.innerHTML = MENU_ITEMS.filter(m=>filter==='all'||m.cat===filter).map(m=>`
      <div class="menu-card tilt">
        <div class="menu-card-media"><img src="${m.img}" alt="${m.name}" loading="lazy"><div class="pour"></div></div>
        <div class="menu-card-body">
          <h4>${m.name}</h4><p>${m.desc}</p>
          <div class="menu-card-foot">
            <span class="price">৳${m.price}</span>
            <button class="add-btn" aria-label="Add ${m.name} to cart" data-name="${m.name}">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
            </button>
          </div>
        </div>
      </div>`).join('');
    bindTilt(menuGrid.querySelectorAll('.tilt'));
    menuGrid.querySelectorAll('.add-btn').forEach(b=>b.addEventListener('click', addToCart));
  }
  renderMenu();
  document.getElementById('menuFilters').addEventListener('click', e=>{
    const btn = e.target.closest('.chip'); if(!btn) return;
    document.querySelectorAll('#menuFilters .chip').forEach(c=>c.classList.remove('active'));
    btn.classList.add('active');
    renderMenu(btn.dataset.filter);
  });

  /* ---------- CART (front-end only) ---------- */
  let cartCount = 0;
  const cartCountEl = document.getElementById('cartCount');
  function addToCart(e){
    cartCount++;
    cartCountEl.textContent = cartCount;
    const btn = e.currentTarget;
    btn.style.transform='scale(1.3) rotate(90deg)';
    setTimeout(()=>btn.style.transform='',250);
  }

  /* ---------- 3D TILT ---------- */
  function bindTilt(nodes){
    nodes.forEach(card=>{
      card.addEventListener('mousemove', e=>{
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left)/r.width - .5;
        const py = (e.clientY - r.top)/r.height - .5;
        card.style.transform = `rotateY(${px*10}deg) rotateX(${-py*10}deg) translateZ(6px)`;
      });
      card.addEventListener('mouseleave', ()=> card.style.transform = '');
    });
  }

  /* ================= RENDER: BOOKS ================= */
  const shelfGrid = document.getElementById('shelfGrid');
  const noBooks = document.getElementById('noBooks');
  function renderBooks(){
    const cat = document.querySelector('#bookFilters .chip.active').dataset.cat;
    const q = document.getElementById('bookSearch').value.trim().toLowerCase();
    const filtered = BOOKS.filter(b=>{
      const catOk = cat==='all' || b.cat===cat;
      const qOk = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
      return catOk && qOk;
    });
    noBooks.hidden = filtered.length>0;
    shelfGrid.innerHTML = filtered.map(b=>`
      <div class="book-item">
        <div class="book-spine" style="background:linear-gradient(160deg, ${b.color}, ${shade(b.color,-18)})">
          <span class="book-cat-tag">${b.cat}</span>
          <div><h5>${b.title}</h5><span>${b.author}</span></div>
        </div>
      </div>`).join('');
  }
  function shade(hex, pct){
    const n = parseInt(hex.slice(1),16);
    const r = Math.min(255,Math.max(0,(n>>16)+pct));
    const g = Math.min(255,Math.max(0,((n>>8)&0xff)+pct));
    const b = Math.min(255,Math.max(0,(n&0xff)+pct));
    return `rgb(${r},${g},${b})`;
  }
  renderBooks();
  document.getElementById('bookFilters').addEventListener('click', e=>{
    const btn = e.target.closest('.chip'); if(!btn) return;
    document.querySelectorAll('#bookFilters .chip').forEach(c=>c.classList.remove('active'));
    btn.classList.add('active');
    renderBooks();
  });
  document.getElementById('bookSearch').addEventListener('input', renderBooks);

  /* ================= RENDER: BESTSELLERS ================= */
  document.getElementById('bestsellerRow').innerHTML = BESTSELLERS.map((t,i)=>`
    <div class="bs-pill"><span class="bs-rank">${i+1}</span><span class="title">${t}</span></div>`).join('');

  /* ================= RENDER: GALLERY ================= */
  const masonryGrid = document.getElementById('masonryGrid');
  masonryGrid.innerHTML = GALLERY.map((g,i)=>`
    <div class="masonry-item" data-idx="${i}" style="${g.tall?'':''}">
      <img src="${g.img}" alt="${g.tag}" loading="lazy" style="${g.tall?'aspect-ratio:3/4;object-fit:cover;':'aspect-ratio:4/3;object-fit:cover;'}">
      <span class="masonry-tag">${g.tag}</span>
    </div>`).join('');

  /* ---------- LIGHTBOX ---------- */
  const lightbox = document.getElementById('lightbox');
  const lightboxFrame = document.getElementById('lightboxFrame');
  let lbIndex = 0;
  function openLightbox(i){ lbIndex=i; lightboxFrame.innerHTML = `<img src="${GALLERY[i].img}" alt="${GALLERY[i].tag}">`; lightbox.classList.add('open'); }
  masonryGrid.querySelectorAll('.masonry-item').forEach(item=>{
    item.addEventListener('click', ()=>openLightbox(parseInt(item.dataset.idx,10)));
  });
  document.getElementById('lightboxClose').addEventListener('click', ()=>lightbox.classList.remove('open'));
  lightbox.addEventListener('click', e=>{ if(e.target===lightbox) lightbox.classList.remove('open'); });
  document.getElementById('lightboxNext').addEventListener('click', ()=>openLightbox((lbIndex+1)%GALLERY.length));
  document.getElementById('lightboxPrev').addEventListener('click', ()=>openLightbox((lbIndex-1+GALLERY.length)%GALLERY.length));
  document.addEventListener('keydown', e=>{
    if(!lightbox.classList.contains('open')) return;
    if(e.key==='Escape') lightbox.classList.remove('open');
    if(e.key==='ArrowRight') openLightbox((lbIndex+1)%GALLERY.length);
    if(e.key==='ArrowLeft') openLightbox((lbIndex-1+GALLERY.length)%GALLERY.length);
  });

  /* ================= RENDER: EVENTS ================= */
  document.getElementById('eventsGrid').innerHTML = EVENTS.map(ev=>`
    <div class="event-card reveal-up in">
      <div class="event-date"><span class="d">${ev.day}</span><span class="m">${ev.mon}</span></div>
      <h4>${ev.title}</h4>
      <span class="event-time">${ev.time}</span>
      <p>${ev.desc}</p>
    </div>`).join('');

  /* ================= RENDER: TESTIMONIALS ================= */
  const testiTrack = document.getElementById('testiTrack');
  testiTrack.innerHTML = `<div class="testi-track-inner">${TESTIMONIALS.map(t=>`
    <div class="testi-card">
      <div class="stars">${'★'.repeat(t.stars)}${'☆'.repeat(5-t.stars)}</div>
      <blockquote>&ldquo;${t.quote}&rdquo;</blockquote>
      <div class="testi-name">${t.name}</div>
      <div class="testi-role">${t.role}</div>
    </div>`).join('')}</div>`;
  const testiInner = testiTrack.querySelector('.testi-track-inner');
  const testiDots = document.getElementById('testiDots');
  testiDots.innerHTML = TESTIMONIALS.map((_,i)=>`<span data-i="${i}" class="${i===0?'active':''}"></span>`).join('');
  let testiIdx = 0;
  function goTesti(i){
    testiIdx = (i+TESTIMONIALS.length)%TESTIMONIALS.length;
    testiInner.style.transform = `translateX(-${testiIdx*100}%)`;
    testiDots.querySelectorAll('span').forEach((d,j)=>d.classList.toggle('active', j===testiIdx));
  }
  document.getElementById('testiNext').addEventListener('click', ()=>goTesti(testiIdx+1));
  document.getElementById('testiPrev').addEventListener('click', ()=>goTesti(testiIdx-1));
  testiDots.addEventListener('click', e=>{ const d=e.target.closest('span'); if(d) goTesti(parseInt(d.dataset.i,10)); });
  let testiAuto = setInterval(()=>goTesti(testiIdx+1), 6000);
  testiTrack.addEventListener('mouseenter', ()=>clearInterval(testiAuto));
  testiTrack.addEventListener('mouseleave', ()=>testiAuto=setInterval(()=>goTesti(testiIdx+1), 6000));

  /* ================= RENDER: BLOG ================= */
  document.getElementById('blogGrid').innerHTML = BLOG.map(b=>`
    <a href="#" class="blog-card">
      <div class="blog-media"><img src="${b.img}" alt="${b.title}" loading="lazy"></div>
      <div class="blog-body">
        <div class="blog-meta"><span>${b.cat}</span><span>${b.time}</span></div>
        <h4>${b.title}</h4>
      </div>
    </a>`).join('');

  /* ---------- CONTACT FORM ---------- */
  document.getElementById('contactForm').addEventListener('submit', e=>{
    e.preventDefault();
    document.getElementById('formNote').hidden = false;
    e.target.reset();
    setTimeout(()=>document.getElementById('formNote').hidden = true, 5000);
  });
  document.getElementById('newsletterBtn').addEventListener('click', ()=>{
    document.getElementById('newsletterNote').hidden = false;
    setTimeout(()=>document.getElementById('newsletterNote').hidden = true, 4000);
  });

  /* ================= THREE.JS HERO SCENE ================= */
  initHeroScene();
  function initHeroScene(){
    const canvas = document.getElementById('heroCanvas');
    if(!window.THREE || !canvas) return;
    const renderer = new THREE.WebGLRenderer({ canvas, alpha:true, antialias:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, canvas.clientWidth/canvas.clientHeight, 0.1, 100);
    camera.position.set(0,0,11);

    const goldMat = new THREE.MeshStandardMaterial({ color:0xC9A227, roughness:.35, metalness:.4 });
    const espressoMat = new THREE.MeshStandardMaterial({ color:0x5C3A1C, roughness:.5, metalness:.2 });
    const creamMat = new THREE.MeshStandardMaterial({ color:0xF5EDE1, roughness:.6, metalness:.1 });

    const group = new THREE.Group();
    scene.add(group);

    // coffee beans: two joined ellipsoids approximated with scaled spheres + crease
    function makeBean(mat){
      const g = new THREE.Group();
      const geo = new THREE.SphereGeometry(0.42, 20, 20);
      const body = new THREE.Mesh(geo, mat);
      body.scale.set(1,0.72,0.5);
      g.add(body);
      const creaseGeo = new THREE.BoxGeometry(0.03,0.5,0.14);
      const crease = new THREE.Mesh(creaseGeo, new THREE.MeshStandardMaterial({color:0x1A120B, roughness:.8}));
      crease.position.z = 0.14;
      g.add(crease);
      return g;
    }
    // book: simple box
    function makeBook(mat){
      const geo = new THREE.BoxGeometry(1.1,0.16,0.8);
      return new THREE.Mesh(geo, mat);
    }
    function makeCup(){
      const g = new THREE.Group();
      const cupGeo = new THREE.CylinderGeometry(0.5,0.4,0.7,24,1,true);
      const cup = new THREE.Mesh(cupGeo, creamMat);
      g.add(cup);
      const handleGeo = new THREE.TorusGeometry(0.22,0.06,10,20,Math.PI*1.4);
      const handle = new THREE.Mesh(handleGeo, creamMat);
      handle.position.set(0.55,0,0);
      handle.rotation.z = Math.PI/2.6;
      g.add(handle);
      return g;
    }

    const items = [];
    const mats = [goldMat, espressoMat, creamMat];
    for(let i=0;i<9;i++){
      let mesh;
      const type = i%3;
      if(type===0) mesh = makeBean(mats[i%3]);
      else if(type===1) mesh = makeBook(i%2===0?espressoMat:goldMat);
      else mesh = makeCup();
      const spread = 6.5;
      mesh.position.set((Math.random()-0.5)*spread*1.8, (Math.random()-0.5)*spread, (Math.random()-0.5)*4 - 2);
      mesh.rotation.set(Math.random()*Math.PI, Math.random()*Math.PI, Math.random()*Math.PI);
      const scale = 0.7 + Math.random()*0.6;
      mesh.scale.setScalar(scale);
      group.add(mesh);
      items.push({ mesh, speed: 0.2+Math.random()*0.4, offset: Math.random()*Math.PI*2, rotSpeed:(Math.random()-0.5)*0.006 });
    }

    scene.add(new THREE.AmbientLight(0xffffff, 0.65));
    const dirLight = new THREE.DirectionalLight(0xffe9c4, 1.1);
    dirLight.position.set(4,6,8);
    scene.add(dirLight);
    const rim = new THREE.PointLight(0xC9A227, 0.8, 20);
    rim.position.set(-6,-3,4);
    scene.add(rim);

    let targetRotX = 0, targetRotY = 0;
    window.addEventListener('mousemove', e=>{
      targetRotY = ((e.clientX/window.innerWidth)-0.5) * 0.5;
      targetRotX = ((e.clientY/window.innerHeight)-0.5) * 0.3;
    });

    function resize(){
      const w = canvas.clientWidth, h = canvas.clientHeight;
      renderer.setSize(w,h,false);
      camera.aspect = w/h;
      camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', resize);
    resize();

    const clock = new THREE.Clock();
    function animate(){
      const t = clock.getElapsedTime();
      items.forEach(it=>{
        it.mesh.position.y += Math.sin(t*it.speed + it.offset)*0.0016;
        it.mesh.rotation.x += it.rotSpeed;
        it.mesh.rotation.y += it.rotSpeed*1.3;
      });
      group.rotation.y += (targetRotY - group.rotation.y)*0.03;
      group.rotation.x += (targetRotX - group.rotation.x)*0.03;
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    }
    animate();
  }

});
